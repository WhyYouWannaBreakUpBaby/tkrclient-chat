const http = require("http");
const { WebSocketServer } = require("ws");

const PORT = Number(process.env.PORT || 3000);
const MAX_HISTORY = 100;
const MAX_MESSAGE = 500;

const rooms = new Map(); // room -> { messages: [], clients: Set<WebSocket> }

function roomState(name) {
  if (!rooms.has(name)) rooms.set(name, { messages: [], clients: new Set() });
  return rooms.get(name);
}

function send(ws, payload) {
  if (ws.readyState === 1) ws.send(JSON.stringify(payload));
}

function broadcast(room, payload) {
  for (const ws of room.clients) send(ws, payload);
}

function usersIn(room) {
  return [...room.clients].map(c => c.user).filter(Boolean);
}

function broadcastUsers(room) {
  broadcast(room, { type: "users", users: usersIn(room) });
}

const server = http.createServer((req, res) => {
  res.writeHead(200, {"content-type":"text/plain; charset=utf-8"});
  res.end("TKR Chat server is running.");
});

const wss = new WebSocketServer({ server });

wss.on("connection", (ws) => {
  ws.roomName = null;
  ws.user = "Guest";

  ws.on("message", (raw) => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { return; }

    if (data.type === "join") {
      const roomName = String(data.room || "general")
        .replace(/[^\w-]/g, "").slice(0, 32) || "general";
      const user = String(data.user || "Guest")
        .replace(/[^\w .-]/g, "").slice(0, 24) || "Guest";

      if (ws.roomName) {
        const oldRoom = roomState(ws.roomName);
        oldRoom.clients.delete(ws);
        broadcastUsers(oldRoom);
      }

      ws.roomName = roomName;
      ws.user = user;
      const room = roomState(roomName);
      room.clients.add(ws);

      send(ws, { type: "history", messages: room.messages });
      send(ws, { type: "system", text: `Joined #${roomName}` });
      broadcastUsers(room);
      return;
    }

    if (data.type === "message" && ws.roomName) {
      const text = String(data.text || "").trim().slice(0, MAX_MESSAGE);
      if (!text) return;

      const message = {
        user: ws.user,
        text,
        time: Date.now()
      };

      const room = roomState(ws.roomName);
      room.messages.push(message);
      if (room.messages.length > MAX_HISTORY) room.messages.shift();

      broadcast(room, { type: "message", message });
    }
  });

  ws.on("close", () => {
    if (!ws.roomName) return;
    const room = roomState(ws.roomName);
    room.clients.delete(ws);
    broadcastUsers(room);
  });
});

server.listen(PORT, () => {
  console.log(`TKR Chat server listening on port ${PORT}`);
});
