# TKR Chat — GitHub Pages + WebSocket server

This project is designed so the **website frontend** can live on GitHub Pages while
the **real-time chat server** runs on a Node.js host.

## Files

- `index.html` — website entry page. You still need this even though `script.js` contains the chat logic.
- `style.css` — appearance.
- `script.js` — browser chat client.
- `server.js` — WebSocket server.
- `package.json` — Node dependencies/start command.

## 1. Put the website on GitHub Pages

Create a GitHub repository, upload:

- `index.html`
- `style.css`
- `script.js`

Enable **Settings → Pages → Deploy from a branch** and select the branch/folder containing those files.

## 2. Put the server on a Node host

Create a separate Node.js service/repository containing:

- `server.js`
- `package.json`

Install and start:

```bash
npm install
npm start
```

Your hosting provider must give the service a public HTTPS/WSS address.

## 3. Connect the website to the server

Open `script.js` and replace:

```js
const WS_URL = "wss://YOUR-CHAT-SERVER.example.com";
```

with your actual WebSocket address, for example:

```js
const WS_URL = "wss://your-chat-server.example.com";
```

Commit/push the changed `script.js`.

## 4. Custom domain

Once GitHub Pages works, you can connect a domain/subdomain such as:

`chat.example.com`

The exact DNS records depend on your domain provider.

## Important

GitHub Pages is static hosting. It cannot run `server.js`.
The frontend and WebSocket server therefore need to be hosted separately.

This starter intentionally keeps the server simple. For a public chat, add authentication,
persistent storage, rate limits, moderation/blocking, reporting, message filtering, and
HTTPS/WSS before opening it to everyone.
